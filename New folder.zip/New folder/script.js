// load math.js\
var express = require('express');
var Excel = require('exceljs');

var app = express();
var parseXlsx = require('excel');

		var http = require('http');
var math = require('mathjs');

// functions and constants
app.get('/', function(req, res) {
	var serverObject = {};
	serverObject.round = math.round(math.e, 3);            // 2.718
	serverObject.atan2 = math.atan2(3, -3) / math.pi;      // 0.75
	serverObject.log = math.log(10000, 10);              // 4
	serverObject.sqrt = math.sqrt(-4);                    // 2i
	serverObject.pow = math.pow([[-1, 2], [3, 1]], 2);   // [[7, 0], [0, 7]]
	serverObject.derivative = math.derivative('x^2 + x', 'x');  // 2 * x + 1
    res.send(serverObject);
});

// expressions
math.eval('12 / (2.3 + 0.7)');    // 4
math.eval('12.7 cm to inch');     // 5 inch
math.eval('sin(45 deg) ^ 2');     // 0.5
math.eval('9 / 3 + 2i');          // 3 + 2i
math.eval('det([-1, 2; 3, 1])');  // -7

// chaining
math.chain(3)
    .add(4)
    .multiply(2)
    .done(); // 14


		// parseXlsx('new.xlsx', '2', function(err, data) {
		//   if(err) throw err;
		// 	// console.log(data);
		//     // data is an array of arrays
		// });

// 		var options = {
//     filename: 'new.xlsx',
//     useStyles: true,
//     useSharedStrings: true
// };
// var workbook = new Excel.stream.xlsx.WorkbookWriter(options);
// 		var worksheet = workbook.getWorksheet(1);
		// console.log(worksheet);

		// read from a file
// var recarr=[];
var recobj=[];
	var workbook = new Excel.Workbook();
	workbook.xlsx.readFile("new1.xlsx")
	    .then(function() {
				var worksheet = workbook.getWorksheet(1);
				var head=worksheet.getColumn(1);
				var a=2;
	      // console.log(worksheet.getCell("A"+a).value);
				while (worksheet.getCell("A"+a)!="" && worksheet.getCell("B"+a)!="") {
					var m=worksheet.getCell("A"+a).value;
					var n=worksheet.getCell("B"+a).value;
					// var c=m.add(n);
					var c=math.chain(m)
					    .add(n)
							.done();
					console.log(c);
					a++;
					recobj.push(c);
				}
	    });
			app.get('/new', function(req, res) {

				// res.setHeader('Access-Control-Allow-Credentials', true);

				// Pass to next layer of middleware
				// next();
				res.send(recobj);

			});

		app.listen(8080);
		console.log('Listening on port 8080...');


// http.createServer(function (req, res) {
//     res.writeHead(200, {'Content-Type': 'text/plain'});
//     res.end('Hello World!');
// }).listen(8080);
